This dataset contains presence records for the Canada region of the NCEAS (National Center for Ecological Analysis and Synthesis) dataset (Elith et al. 2020).

The records are the combined presence records of the presence-only and presence-absence data of the NCEAS data.
Each species is stored in a seperate folder. 

The species records were parted into spatialBlocks with the blockCV package by Valavi et al. 2019:
Valavi, R. et al. 2019. blockCV : An r package for generating spatially or environmentally separated folds for k ‐fold cross‐validation of species distribution models (D Warton, Ed.). - Methods Ecol Evol 10: 225–232.

The data structure follow the follwing concept:

The first folder (e.g. can01) contains all species records as geopackage (e.g. can01.gpkg) and folders for each step 
of the forward-fold-metric-estimation (FFME). In each folder two of seven spatial blocks were left out for validation.
In total 21 combinations af training and validation data are possible. The folders (e.g. can01_01) contain training and test
data as geopackage (e.g. can01_01_test.gpkg, can01_01_train.gpkg) and the training data also as csv file to train
in spatialMaxent (can01_01_train.csv).

The workflow for the preparation of this dataset can be found here: https://nature40.github.io/spatialMaxentPaper/docs/060_nceas/

For more information on the NCEAS data see:
Elith, J., Graham, C.H., Valavi, R., Abegg, M., Bruce, C., Ferrier, S., Ford, A., Guisan, A., Hijmans, R.J., Huettmann, F., Lohmann, L.G., Loiselle, B.A., Moritz, C., Overton, J.McC., Peterson, A.T., Phillips, S., Richardson, K., Williams, S., Wiser, S.K., Wohlgemuth, T., Zimmermann, N.E. (2020). Presence-only and presence-absence data for comparing species distribution modeling methods. Biodiversity Informatics 15:69-80