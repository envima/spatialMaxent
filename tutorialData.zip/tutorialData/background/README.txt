This dataset contains 10000 background points for the Canada region of the NCEAS (National Center for Ecological Analysis and Synthesis) dataset (Elith et al. 2020).

The background points were obtained using conditioned latin hypercube sampling with the R-package clhs by Roudier et al. 2011:
Roudier, P. 2011. clhs: a R package for conditioned Latin hypercube sampling. in press.

and the environmental rasters of the NCEAS dataset for the canada region. 

The dataset is stored as csv file ready to use in spatialMaxent and as geopackage.

The workflow for the preparation of this dataset can be found here: https://nature40.github.io/spatialMaxentPaper/docs/080_bg/

For more information on the NCEAS data see:
Elith, J., Graham, C.H., Valavi, R., Abegg, M., Bruce, C., Ferrier, S., Ford, A., Guisan, A., Hijmans, R.J., Huettmann, F., Lohmann, L.G., Loiselle, B.A., Moritz, C., Overton, J.McC., Peterson, A.T., Phillips, S., Richardson, K., Williams, S., Wiser, S.K., Wohlgemuth, T., Zimmermann, N.E. (2020). Presence-only and presence-absence data for comparing species distribution modeling methods. Biodiversity Informatics 15:69-80